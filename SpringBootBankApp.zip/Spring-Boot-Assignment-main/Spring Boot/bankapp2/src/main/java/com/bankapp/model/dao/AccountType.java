package com.bankapp.model.dao;

public enum AccountType {

	SA,CA
}
